import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "../../components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "../../components/ui/table";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import Link from "next/link";

interface Proposta {
  id: number;
  orcamentoId: number;
  clienteNome: string;
  cidade: string;
  tipoOrcamento: string;
  valorProposto: number;
  status: string;
  dataEnvio: string;
}

export default function OrcamentosPage() {
  const [propostas, setPropostas] = React.useState<Proposta[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filtro, setFiltro] = React.useState("todos");

  React.useEffect(() => {
    // Simulação de chamada à API
    const fetchPropostas = async () => {
      try {
        // Em um ambiente real, isso seria uma chamada à API
        // const response = await fetch(`/api/marceneiros/propostas?status=${filtro}`);
        // const data = await response.json();
        // setPropostas(data.propostas);
        
        // Simulação de dados
        const mockPropostas = [
          {
            id: 2001,
            orcamentoId: 1001,
            clienteNome: "João Silva",
            cidade: "Campinas",
            tipoOrcamento: "Apartamento completo",
            valorProposto: 170000,
            status: "enviada",
            dataEnvio: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
          },
          {
            id: 2002,
            orcamentoId: 1003,
            clienteNome: "Pedro Santos",
            cidade: "Campinas",
            tipoOrcamento: "Móveis específicos",
            valorProposto: 45000,
            status: "visualizada",
            dataEnvio: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString()
          },
          {
            id: 2003,
            orcamentoId: 1004,
            clienteNome: "Ana Souza",
            cidade: "Jundiaí",
            tipoOrcamento: "Apartamento completo",
            valorProposto: 190000,
            status: "aceita",
            dataEnvio: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString()
          }
        ];
        
        // Aplicar filtro se necessário
        let filteredPropostas = mockPropostas;
        if (filtro !== "todos") {
          filteredPropostas = mockPropostas.filter(p => p.status === filtro);
        }
        
        setPropostas(filteredPropostas);
        setLoading(false);
      } catch (error) {
        console.error("Erro ao buscar propostas:", error);
        setLoading(false);
      }
    };

    fetchPropostas();
  }, [filtro]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "enviada":
        return <Badge variant="secondary">Enviada</Badge>;
      case "visualizada":
        return <Badge variant="warning">Visualizada</Badge>;
      case "em_negociacao":
        return <Badge>Em Negociação</Badge>;
      case "aceita":
        return <Badge variant="success">Aceita</Badge>;
      case "recusada":
        return <Badge variant="danger">Recusada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatarValor = (valor: number) => {
    return valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  };

  const formatarData = (dataString: string) => {
    const data = new Date(dataString);
    return data.toLocaleDateString('pt-BR');
  };

  return (
    <div className="container-page">
      <Card>
        <CardHeader>
          <CardTitle>Meus Orçamentos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex flex-wrap gap-2">
            <Button 
              variant={filtro === "todos" ? "default" : "outline"}
              onClick={() => setFiltro("todos")}
            >
              Todos
            </Button>
            <Button 
              variant={filtro === "enviada" ? "default" : "outline"}
              onClick={() => setFiltro("enviada")}
            >
              Enviados
            </Button>
            <Button 
              variant={filtro === "visualizada" ? "default" : "outline"}
              onClick={() => setFiltro("visualizada")}
            >
              Visualizados
            </Button>
            <Button 
              variant={filtro === "aceita" ? "default" : "outline"}
              onClick={() => setFiltro("aceita")}
            >
              Aceitos
            </Button>
            <Button 
              variant={filtro === "recusada" ? "default" : "outline"}
              onClick={() => setFiltro("recusada")}
            >
              Recusados
            </Button>
          </div>

          {loading ? (
            <p className="text-center py-4">Carregando orçamentos...</p>
          ) : propostas.length === 0 ? (
            <p className="text-center py-4">Nenhum orçamento encontrado.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Cidade</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Valor Proposto</TableHead>
                  <TableHead>Data de Envio</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {propostas.map((proposta) => (
                  <TableRow key={proposta.id}>
                    <TableCell>{proposta.orcamentoId}</TableCell>
                    <TableCell>{proposta.clienteNome}</TableCell>
                    <TableCell>{proposta.cidade}</TableCell>
                    <TableCell>{proposta.tipoOrcamento}</TableCell>
                    <TableCell>{formatarValor(proposta.valorProposto)}</TableCell>
                    <TableCell>{formatarData(proposta.dataEnvio)}</TableCell>
                    <TableCell>{getStatusBadge(proposta.status)}</TableCell>
                    <TableCell>
                      <Link href={`/marceneiro/orcamentos/${proposta.orcamentoId}`}>
                        <Button variant="outline" size="sm">
                          Ver Detalhes
                        </Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
