import React from "react";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "../../../components/ui/card";
import { Badge } from "../../../components/ui/badge";
import { Button } from "../../../components/ui/button";
import { Textarea } from "../../../components/ui/textarea";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";

export default function DetalhesOrcamentoPage({ params }: { params: { id: string } }) {
  const [orcamento, setOrcamento] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [valorProposta, setValorProposta] = React.useState("");
  const [detalhesProposta, setDetalhesProposta] = React.useState("");
  const [enviando, setEnviando] = React.useState(false);
  const [enviado, setEnviado] = React.useState(false);

  React.useEffect(() => {
    // Simulação de chamada à API
    const fetchOrcamento = async () => {
      try {
        // Em um ambiente real, isso seria uma chamada à API
        // const response = await fetch(`/api/orcamentos/${params.id}`);
        // const data = await response.json();
        // setOrcamento(data);
        
        // Simulação de dados
        const mockOrcamento = {
          id: parseInt(params.id),
          cidade: "Campinas",
          tamanhoApartamento: "80",
          tipoOrcamento: "Apartamento completo",
          detalhes: "Preciso de móveis para todos os ambientes do meu apartamento novo. Gostaria de um estilo moderno e funcional, com bastante espaço para armazenamento. Os cômodos incluem sala de estar, sala de jantar, cozinha, 2 quartos, 2 banheiros e uma varanda.",
          valorEstimado: 176000,
          status: "pendente",
          dataCriacao: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          clienteNome: "João Silva",
          clienteEmail: "joao.silva@exemplo.com",
          clienteTelefone: "(19) 98765-4321"
        };
        
        setOrcamento(mockOrcamento);
        setLoading(false);
      } catch (error) {
        console.error("Erro ao buscar orçamento:", error);
        setLoading(false);
      }
    };

    fetchOrcamento();
  }, [params.id]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return <Badge variant="warning">Pendente</Badge>;
      case "em_analise":
        return <Badge variant="secondary">Em Análise</Badge>;
      case "aceito":
        return <Badge variant="success">Aceito</Badge>;
      case "recusado":
        return <Badge variant="danger">Recusado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatarValor = (valor: number) => {
    return valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  };

  const formatarData = (dataString: string) => {
    const data = new Date(dataString);
    return data.toLocaleDateString('pt-BR');
  };

  const handleEnviarProposta = async () => {
    setEnviando(true);
    
    try {
      // Em um ambiente real, isso seria uma chamada à API
      // const response = await fetch(`/api/orcamentos/${params.id}/propostas`, {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   body: JSON.stringify({
      //     marceneiroId: 101, // ID do marceneiro logado
      //     valorProposto: parseFloat(valorProposta.replace(/[^\d,]/g, '').replace(',', '.')),
      //     detalhes: detalhesProposta
      //   }),
      // });
      // const data = await response.json();
      
      // Simulação de resposta
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setEnviado(true);
      setEnviando(false);
    } catch (error) {
      console.error("Erro ao enviar proposta:", error);
      setEnviando(false);
    }
  };

  if (loading) {
    return (
      <div className="container-page">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center py-4">Carregando detalhes do orçamento...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!orcamento) {
    return (
      <div className="container-page">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center py-4">Orçamento não encontrado.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container-page">
      <div className="mb-4">
        <Button variant="outline" onClick={() => window.history.back()}>
          Voltar
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Detalhes do Orçamento #{orcamento.id}</CardTitle>
                {getStatusBadge(orcamento.status)}
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Cliente</h3>
                  <p className="mt-1">{orcamento.clienteNome}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Contato</h3>
                  <p className="mt-1">{orcamento.clienteEmail}</p>
                  <p>{orcamento.clienteTelefone}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Cidade</h3>
                  <p className="mt-1">{orcamento.cidade}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Data da Solicitação</h3>
                  <p className="mt-1">{formatarData(orcamento.dataCriacao)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Tipo de Orçamento</h3>
                  <p className="mt-1">{orcamento.tipoOrcamento}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Tamanho do Apartamento</h3>
                  <p className="mt-1">{orcamento.tamanhoApartamento} m²</p>
                </div>
                <div className="md:col-span-2">
                  <h3 className="text-sm font-medium text-gray-500">Valor Estimado</h3>
                  <p className="mt-1 text-xl font-semibold text-orange-600">{formatarValor(orcamento.valorEstimado)}</p>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-2">Detalhes do Projeto</h3>
                <div className="bg-gray-50 p-4 rounded-md">
                  <p className="whitespace-pre-line">{orcamento.detalhes}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Enviar Proposta</CardTitle>
            </CardHeader>
            <CardContent>
              {enviado ? (
                <div className="text-center py-4">
                  <div className="mb-4 text-green-600">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium mb-2">Proposta Enviada!</h3>
                  <p className="text-gray-600">Sua proposta foi enviada com sucesso. O cliente será notificado e poderá entrar em contato com você.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="valor">Valor da Proposta</Label>
                    <Input
                      id="valor"
                      placeholder="R$ 0,00"
                      value={valorProposta}
                      onChange={(e) => setValorProposta(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="detalhes">Detalhes da Proposta</Label>
                    <Textarea
                      id="detalhes"
                      placeholder="Descreva os detalhes da sua proposta, incluindo materiais, prazos e condições..."
                      rows={6}
                      value={detalhesProposta}
                      onChange={(e) => setDetalhesProposta(e.target.value)}
                    />
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter>
              {!enviado && (
                <Button 
                  className="w-full" 
                  onClick={handleEnviarProposta}
                  disabled={enviando || !valorProposta || !detalhesProposta}
                >
                  {enviando ? "Enviando..." : "Enviar Proposta"}
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
