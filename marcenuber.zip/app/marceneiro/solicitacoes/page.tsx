import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "../../components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "../../components/ui/table";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import Link from "next/link";

interface Orcamento {
  id: number;
  cidade: string;
  tamanhoApartamento: string;
  tipoOrcamento: string;
  detalhes: string;
  valorEstimado: number;
  status: string;
  dataCriacao: string;
  clienteNome: string;
  clienteEmail: string;
}

export default function SolicitacoesPage() {
  const [orcamentos, setOrcamentos] = React.useState<Orcamento[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filtro, setFiltro] = React.useState("pendente");

  React.useEffect(() => {
    // Simulação de chamada à API
    const fetchOrcamentos = async () => {
      try {
        // Em um ambiente real, isso seria uma chamada à API
        // const response = await fetch(`/api/orcamentos?status=${filtro}`);
        // const data = await response.json();
        // setOrcamentos(data.orcamentos);
        
        // Simulação de dados
        const mockOrcamentos = [
          {
            id: 1001,
            cidade: "Campinas",
            tamanhoApartamento: "80",
            tipoOrcamento: "Apartamento completo",
            detalhes: "Preciso de móveis para todos os ambientes do meu apartamento novo.",
            valorEstimado: 176000,
            status: "pendente",
            dataCriacao: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
            clienteNome: "João Silva",
            clienteEmail: "joao.silva@exemplo.com"
          },
          {
            id: 1003,
            cidade: "Campinas",
            tamanhoApartamento: "60",
            tipoOrcamento: "Móveis específicos",
            detalhes: "Preciso de um armário embutido para o quarto principal.",
            valorEstimado: 48000,
            status: "pendente",
            dataCriacao: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
            clienteNome: "Pedro Santos",
            clienteEmail: "pedro.santos@exemplo.com"
          }
        ];
        
        setOrcamentos(mockOrcamentos);
        setLoading(false);
      } catch (error) {
        console.error("Erro ao buscar orçamentos:", error);
        setLoading(false);
      }
    };

    fetchOrcamentos();
  }, [filtro]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return <Badge variant="warning">Pendente</Badge>;
      case "em_analise":
        return <Badge variant="secondary">Em Análise</Badge>;
      case "aceito":
        return <Badge variant="success">Aceito</Badge>;
      case "recusado":
        return <Badge variant="danger">Recusado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatarValor = (valor: number) => {
    return valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  };

  const formatarData = (dataString: string) => {
    const data = new Date(dataString);
    return data.toLocaleDateString('pt-BR');
  };

  return (
    <div className="container-page">
      <Card>
        <CardHeader>
          <CardTitle>Solicitações de Orçamentos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex flex-wrap gap-2">
            <Button 
              variant={filtro === "pendente" ? "default" : "outline"}
              onClick={() => setFiltro("pendente")}
            >
              Pendentes
            </Button>
            <Button 
              variant={filtro === "em_analise" ? "default" : "outline"}
              onClick={() => setFiltro("em_analise")}
            >
              Em Análise
            </Button>
            <Button 
              variant={filtro === "aceito" ? "default" : "outline"}
              onClick={() => setFiltro("aceito")}
            >
              Aceitos
            </Button>
            <Button 
              variant={filtro === "todos" ? "default" : "outline"}
              onClick={() => setFiltro("todos")}
            >
              Todos
            </Button>
          </div>

          {loading ? (
            <p className="text-center py-4">Carregando solicitações...</p>
          ) : orcamentos.length === 0 ? (
            <p className="text-center py-4">Nenhuma solicitação encontrada.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Cidade</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Valor Estimado</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orcamentos.map((orcamento) => (
                  <TableRow key={orcamento.id}>
                    <TableCell>{orcamento.id}</TableCell>
                    <TableCell>{orcamento.clienteNome}</TableCell>
                    <TableCell>{orcamento.cidade}</TableCell>
                    <TableCell>{orcamento.tipoOrcamento}</TableCell>
                    <TableCell>{formatarValor(orcamento.valorEstimado)}</TableCell>
                    <TableCell>{formatarData(orcamento.dataCriacao)}</TableCell>
                    <TableCell>{getStatusBadge(orcamento.status)}</TableCell>
                    <TableCell>
                      <Link href={`/marceneiro/solicitacoes/${orcamento.id}`}>
                        <Button variant="outline" size="sm">
                          Ver Detalhes
                        </Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
