import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "../../components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../../components/ui/tabs";
import { Label } from "../../components/ui/label";
import { Input } from "../../components/ui/input";
import { Textarea } from "../../components/ui/textarea";
import { Button } from "../../components/ui/button";

export default function PerfilPage() {
  const [perfil, setPerfil] = React.useState({
    nome: "Marchetto Interni",
    email: "contato@marchettointerni.com.br",
    telefone: "(19) 99999-1111",
    cidade: "Campinas",
    regiao: "Região Metropolitana de Campinas",
    especialidades: "Móveis de alto padrão, Acabamento premium",
    descricao: "Especialistas em móveis personalizados com acabamento premium há mais de 15 anos."
  });
  
  const [editando, setEditando] = React.useState(false);
  const [salvando, setSalvando] = React.useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPerfil(prev => ({ ...prev, [name]: value }));
  };

  const handleSalvar = async () => {
    setSalvando(true);
    
    try {
      // Em um ambiente real, isso seria uma chamada à API
      // const response = await fetch('/api/marceneiros/perfil', {
      //   method: 'PUT',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   body: JSON.stringify(perfil),
      // });
      // const data = await response.json();
      
      // Simulação de resposta
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setEditando(false);
      setSalvando(false);
    } catch (error) {
      console.error("Erro ao salvar perfil:", error);
      setSalvando(false);
    }
  };

  return (
    <div className="container-page">
      <Tabs defaultValue="perfil">
        <TabsList className="mb-6">
          <TabsTrigger value="perfil">Perfil</TabsTrigger>
          <TabsTrigger value="portfolio">Portfólio</TabsTrigger>
          <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
        </TabsList>
        
        <TabsContent value="perfil">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Informações do Perfil</CardTitle>
                {!editando ? (
                  <Button variant="outline" onClick={() => setEditando(true)}>
                    Editar Perfil
                  </Button>
                ) : (
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setEditando(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleSalvar} disabled={salvando}>
                      {salvando ? "Salvando..." : "Salvar"}
                    </Button>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="nome">Nome da Marcenaria</Label>
                  {editando ? (
                    <Input
                      id="nome"
                      name="nome"
                      value={perfil.nome}
                      onChange={handleChange}
                      className="mt-1"
                    />
                  ) : (
                    <p className="mt-1 text-lg">{perfil.nome}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="email">E-mail</Label>
                  {editando ? (
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={perfil.email}
                      onChange={handleChange}
                      className="mt-1"
                    />
                  ) : (
                    <p className="mt-1">{perfil.email}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="telefone">Telefone</Label>
                  {editando ? (
                    <Input
                      id="telefone"
                      name="telefone"
                      value={perfil.telefone}
                      onChange={handleChange}
                      className="mt-1"
                    />
                  ) : (
                    <p className="mt-1">{perfil.telefone}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="cidade">Cidade</Label>
                  {editando ? (
                    <Input
                      id="cidade"
                      name="cidade"
                      value={perfil.cidade}
                      onChange={handleChange}
                      className="mt-1"
                    />
                  ) : (
                    <p className="mt-1">{perfil.cidade}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="regiao">Região de Atuação</Label>
                  {editando ? (
                    <Input
                      id="regiao"
                      name="regiao"
                      value={perfil.regiao}
                      onChange={handleChange}
                      className="mt-1"
                    />
                  ) : (
                    <p className="mt-1">{perfil.regiao}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="especialidades">Especialidades</Label>
                  {editando ? (
                    <Input
                      id="especialidades"
                      name="especialidades"
                      value={perfil.especialidades}
                      onChange={handleChange}
                      className="mt-1"
                    />
                  ) : (
                    <p className="mt-1">{perfil.especialidades}</p>
                  )}
                </div>
                
                <div className="md:col-span-2">
                  <Label htmlFor="descricao">Descrição</Label>
                  {editando ? (
                    <Textarea
                      id="descricao"
                      name="descricao"
                      value={perfil.descricao}
                      onChange={handleChange}
                      className="mt-1"
                      rows={4}
                    />
                  ) : (
                    <p className="mt-1">{perfil.descricao}</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="portfolio">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Meu Portfólio</CardTitle>
                <Button>Adicionar Projeto</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <div className="aspect-video bg-gray-200 rounded-t-lg flex items-center justify-center">
                    <span className="text-gray-500">Imagem do Projeto</span>
                  </div>
                  <CardContent className="pt-4">
                    <h3 className="text-lg font-semibold mb-2">Cozinha Planejada - Residencial Villa Flora</h3>
                    <p className="text-gray-600">Projeto completo de cozinha com ilha central e acabamento em laca.</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <div className="aspect-video bg-gray-200 rounded-t-lg flex items-center justify-center">
                    <span className="text-gray-500">Imagem do Projeto</span>
                  </div>
                  <CardContent className="pt-4">
                    <h3 className="text-lg font-semibold mb-2">Home Office - Apartamento Swiss Park</h3>
                    <p className="text-gray-600">Escritório planejado com mesa integrada e armários superiores.</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <div className="aspect-video bg-gray-200 rounded-t-lg flex items-center justify-center">
                    <span className="text-gray-500">Imagem do Projeto</span>
                  </div>
                  <CardContent className="pt-4">
                    <h3 className="text-lg font-semibold mb-2">Dormitório Completo - Condomínio Galleria</h3>
                    <p className="text-gray-600">Conjunto completo com guarda-roupa, cama e criados-mudos.</p>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="configuracoes">
          <Card>
            <CardHeader>
              <CardTitle>Configurações da Conta</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Alterar Senha</h3>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="senha-atual">Senha Atual</Label>
                      <Input id="senha-atual" type="password" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="nova-senha">Nova Senha</Label>
                      <Input id="nova-senha" type="password" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="confirmar-senha">Confirmar Nova Senha</Label>
                      <Input id="confirmar-senha" type="password" className="mt-1" />
                    </div>
                    <Button>Alterar Senha</Button>
                  </div>
                </div>
                
                <div className="pt-4 border-t">
                  <h3 className="text-lg font-medium mb-2">Notificações</h3>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="notif-email" className="rounded" defaultChecked />
                    <Label htmlFor="notif-email">Receber notificações por e-mail</Label>
                  </div>
                  <div className="flex items-center space-x-2 mt-2">
                    <input type="checkbox" id="notif-sms" className="rounded" />
                    <Label htmlFor="notif-sms">Receber notificações por SMS</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
