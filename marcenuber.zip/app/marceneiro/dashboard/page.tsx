import React from "react";
import Link from "next/link";
import { Card, CardContent } from "../../components/ui/card";
import { Button } from "../../components/ui/button";

export default function DashboardPage() {
  const [estatisticas, setEstatisticas] = React.useState({
    solicitacoesPendentes: 2,
    orcamentosEmAndamento: 3,
    orcamentosAceitos: 1,
    visualizacoesDoPerfilUltimos30Dias: 45
  });

  return (
    <div className="container-page">
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex flex-col items-center">
              <span className="text-3xl font-bold text-orange-600">{estatisticas.solicitacoesPendentes}</span>
              <span className="text-gray-600 mt-2">Solicitações Pendentes</span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex flex-col items-center">
              <span className="text-3xl font-bold text-orange-600">{estatisticas.orcamentosEmAndamento}</span>
              <span className="text-gray-600 mt-2">Orçamentos em Andamento</span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex flex-col items-center">
              <span className="text-3xl font-bold text-orange-600">{estatisticas.orcamentosAceitos}</span>
              <span className="text-gray-600 mt-2">Orçamentos Aceitos</span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex flex-col items-center">
              <span className="text-3xl font-bold text-orange-600">{estatisticas.visualizacoesDoPerfilUltimos30Dias}</span>
              <span className="text-gray-600 mt-2">Visualizações do Perfil</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="bg-white">
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-4">Ações Rápidas</h2>
            <div className="space-y-4">
              <Link href="/marceneiro/solicitacoes" className="block">
                <Button className="w-full justify-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clipRule="evenodd" />
                  </svg>
                  Ver Novas Solicitações
                </Button>
              </Link>
              <Link href="/marceneiro/orcamentos" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                  </svg>
                  Gerenciar Meus Orçamentos
                </Button>
              </Link>
              <Link href="/marceneiro/perfil" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                  </svg>
                  Atualizar Meu Perfil
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white">
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-4">Atividade Recente</h2>
            <div className="space-y-4">
              <div className="border-l-4 border-orange-600 pl-4 py-1">
                <p className="text-sm text-gray-600">Hoje</p>
                <p className="font-medium">Nova solicitação de orçamento recebida</p>
                <p className="text-sm text-gray-600">Pedro Santos - Móveis específicos</p>
              </div>
              <div className="border-l-4 border-green-600 pl-4 py-1">
                <p className="text-sm text-gray-600">Ontem</p>
                <p className="font-medium">Proposta visualizada pelo cliente</p>
                <p className="text-sm text-gray-600">João Silva - Apartamento completo</p>
              </div>
              <div className="border-l-4 border-blue-600 pl-4 py-1">
                <p className="text-sm text-gray-600">3 dias atrás</p>
                <p className="font-medium">Mensagem recebida do cliente</p>
                <p className="text-sm text-gray-600">Ana Souza - Apartamento completo</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card className="bg-white">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-4">Dicas para Aumentar suas Chances</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="font-medium">Responda Rapidamente</h3>
              <p className="text-sm text-gray-600">Clientes valorizam marceneiros que respondem às solicitações em até 24 horas.</p>
            </div>
            <div className="space-y-2">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="font-medium">Mantenha seu Portfólio Atualizado</h3>
              <p className="text-sm text-gray-600">Adicione fotos de qualidade dos seus projetos recentes para impressionar os clientes.</p>
            </div>
            <div className="space-y-2">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="font-medium">Detalhe suas Propostas</h3>
              <p className="text-sm text-gray-600">Propostas com detalhes sobre materiais, prazos e condições têm mais chances de serem aceitas.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
