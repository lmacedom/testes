import Link from "next/link";
import { Button } from "./components/ui/button";
import Chatbot from "./components/chatbot/Chatbot";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-orange-600">MarcenUber</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/login" className="text-gray-600 hover:text-orange-600">
              Entrar
            </Link>
            <Link href="/cadastro" className="btn-primary">
              Cadastrar
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-orange-50 to-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h2 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl md:text-6xl mb-4">
                <span className="block">Encontre os melhores</span>
                <span className="block text-orange-600">marceneiros para seu projeto</span>
              </h2>
              <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg md:mt-5 md:text-xl max-w-xl">
                Receba orçamentos instantâneos para seus móveis planejados e conecte-se com os melhores profissionais da sua região.
              </p>
              <div className="mt-8">
                <Button className="btn-primary text-lg px-6 py-3">
                  Começar Agora
                </Button>
              </div>
            </div>
            <div className="md:w-1/2">
              <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-100">
                <Chatbot onSubmit={(data) => console.log("Dados do chatbot:", data)} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Como Funciona */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Como Funciona</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="card text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-orange-600">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Descreva seu Projeto</h3>
              <p className="text-gray-600">
                Informe detalhes sobre o seu projeto de marcenaria através do nosso chatbot intuitivo.
              </p>
            </div>
            <div className="card text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-orange-600">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Receba Orçamentos</h3>
              <p className="text-gray-600">
                Obtenha um orçamento instantâneo e propostas personalizadas de marceneiros qualificados.
              </p>
            </div>
            <div className="card text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-orange-600">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Escolha o Melhor</h3>
              <p className="text-gray-600">
                Compare propostas, avalie portfólios e escolha o marceneiro ideal para realizar seu projeto.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Parceiros */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Nossos Parceiros</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="card flex flex-col items-center">
              <div className="w-32 h-32 bg-gray-200 rounded-full mb-4 flex items-center justify-center">
                <span className="text-gray-500">Logo 1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Marchetto Interni</h3>
              <p className="text-gray-600 text-center">
                Especialistas em móveis personalizados com acabamento premium.
              </p>
            </div>
            <div className="card flex flex-col items-center">
              <div className="w-32 h-32 bg-gray-200 rounded-full mb-4 flex items-center justify-center">
                <span className="text-gray-500">Logo 2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Guaíra Ambientes Planejados</h3>
              <p className="text-gray-600 text-center">
                Soluções completas para todos os ambientes da sua casa.
              </p>
            </div>
            <div className="card flex flex-col items-center">
              <div className="w-32 h-32 bg-gray-200 rounded-full mb-4 flex items-center justify-center">
                <span className="text-gray-500">Logo 3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Águia Dourada Móveis Planejados</h3>
              <p className="text-gray-600 text-center">
                Tradição e qualidade em móveis planejados há mais de 20 anos.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">MarcenUber</h3>
              <p className="text-gray-300">
                Conectando marceneiros a clientes com orçamentos instantâneos.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Links Rápidos</h4>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-300 hover:text-white">Início</Link></li>
                <li><Link href="/como-funciona" className="text-gray-300 hover:text-white">Como Funciona</Link></li>
                <li><Link href="/cadastro" className="text-gray-300 hover:text-white">Cadastro</Link></li>
                <li><Link href="/login" className="text-gray-300 hover:text-white">Login</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Contato</h4>
              <p className="text-gray-300">contato@marcenuber.com.br</p>
              <p className="text-gray-300">(11) 99999-9999</p>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p className="text-gray-300">© 2025 MarcenUber. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
