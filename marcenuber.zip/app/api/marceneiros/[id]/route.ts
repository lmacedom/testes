import { NextRequest, NextResponse } from "next/server";

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const marceneiroId = params.id;
    
    // Aqui seria feita a consulta ao banco de dados
    // Por enquanto, simulamos um marceneiro
    
    // Simulação de dados do marceneiro
    const marceneiro = {
      id: parseInt(marceneiroId),
      nome: "Marchetto Interni",
      email: "contato@marchettointerni.com.br",
      telefone: "(19) 99999-1111",
      cidade: "Campinas",
      regiao: "Região Metropolitana de Campinas",
      especialidades: "Móveis de alto padrão, Acabamento premium",
      descricao: "Especialistas em móveis personalizados com acabamento premium há mais de 15 anos.",
      logoUrl: "/images/marchetto.png",
      avaliacao: 4.8,
      ativo: true,
      portfolio: [
        {
          id: 1,
          titulo: "Cozinha Planejada - Residencial Villa Flora",
          descricao: "Projeto completo de cozinha com ilha central e acabamento em laca.",
          imagens: ["/images/portfolio1.jpg", "/images/portfolio2.jpg"]
        },
        {
          id: 2,
          titulo: "Home Office - Apartamento Swiss Park",
          descricao: "Escritório planejado com mesa integrada e armários superiores.",
          imagens: ["/images/portfolio3.jpg"]
        },
        {
          id: 3,
          titulo: "Dormitório Completo - Condomínio Galleria",
          descricao: "Conjunto completo com guarda-roupa, cama e criados-mudos.",
          imagens: ["/images/portfolio4.jpg", "/images/portfolio5.jpg"]
        }
      ]
    };
    
    return NextResponse.json(marceneiro);
    
  } catch (error) {
    console.error("Erro ao buscar marceneiro:", error);
    return NextResponse.json(
      { error: "Erro ao buscar o marceneiro solicitado" },
      { status: 500 }
    );
  }
}
