import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    // Aqui seria feita a consulta ao banco de dados
    // Por enquanto, simulamos uma lista de marceneiros
    
    // Parâmetros de filtro da URL
    const searchParams = request.nextUrl.searchParams;
    const cidade = searchParams.get("cidade");
    const especialidade = searchParams.get("especialidade");
    
    // Simulação de lista de marceneiros
    let marceneiros = [
      {
        id: 101,
        nome: "Marchetto Interni",
        email: "contato@marchettointerni.com.br",
        telefone: "(19) 99999-1111",
        cidade: "Campinas",
        regiao: "Região Metropolitana de Campinas",
        especialidades: "Móveis de alto padrão, Acabamento premium",
        descricao: "Especialistas em móveis personalizados com acabamento premium há mais de 15 anos.",
        logoUrl: "/images/marchetto.png",
        avaliacao: 4.8,
        ativo: true
      },
      {
        id: 102,
        nome: "Guaíra Ambientes Planejados",
        email: "contato@guairaplanejados.com.br",
        telefone: "(19) 99999-2222",
        cidade: "Campinas",
        regiao: "Região Metropolitana de Campinas",
        especialidades: "Ambientes completos, Cozinhas, Dormitórios",
        descricao: "Soluções completas para todos os ambientes da sua casa com qualidade e preço justo.",
        logoUrl: "/images/guaira.png",
        avaliacao: 4.6,
        ativo: true
      },
      {
        id: 103,
        nome: "Águia Dourada Móveis Planejados",
        email: "contato@aguiadourada.com.br",
        telefone: "(11) 99999-3333",
        cidade: "São Paulo",
        regiao: "Grande São Paulo",
        especialidades: "Móveis residenciais, Escritórios, Projetos comerciais",
        descricao: "Tradição e qualidade em móveis planejados há mais de 20 anos.",
        logoUrl: "/images/aguia.png",
        avaliacao: 4.7,
        ativo: true
      },
      {
        id: 104,
        nome: "Marcenaria Silva & Filhos",
        email: "contato@silvafilhos.com.br",
        telefone: "(19) 99999-4444",
        cidade: "Jundiaí",
        regiao: "Interior de São Paulo",
        especialidades: "Móveis sob medida, Restauração, Madeira maciça",
        descricao: "Empresa familiar com tradição em marcenaria artesanal e móveis sob medida.",
        logoUrl: "/images/silva.png",
        avaliacao: 4.5,
        ativo: true
      }
    ];
    
    // Aplicar filtros se fornecidos
    if (cidade) {
      marceneiros = marceneiros.filter(m => 
        m.cidade.toLowerCase().includes(cidade.toLowerCase()) || 
        m.regiao.toLowerCase().includes(cidade.toLowerCase())
      );
    }
    
    if (especialidade) {
      marceneiros = marceneiros.filter(m => 
        m.especialidades.toLowerCase().includes(especialidade.toLowerCase())
      );
    }
    
    return NextResponse.json({
      success: true,
      marceneiros: marceneiros
    });
    
  } catch (error) {
    console.error("Erro ao listar marceneiros:", error);
    return NextResponse.json(
      { error: "Erro ao listar os marceneiros" },
      { status: 500 }
    );
  }
}
