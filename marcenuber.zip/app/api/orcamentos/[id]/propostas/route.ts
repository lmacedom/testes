import { NextRequest, NextResponse } from "next/server";

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const orcamentoId = params.id;
    const data = await request.json();
    
    // Aqui seria feita a integração com o banco de dados
    // Por enquanto, apenas simulamos o processamento e retornamos uma resposta
    
    // Validação básica dos dados
    if (!data.marceneiroId || !data.valorProposto) {
      return NextResponse.json(
        { error: "Dados incompletos para a proposta" },
        { status: 400 }
      );
    }
    
    // Simulação de ID de proposta
    const propostaId = Math.floor(Math.random() * 10000);
    
    // Resposta com a proposta processada
    return NextResponse.json({
      success: true,
      proposta: {
        id: propostaId,
        orcamentoId: parseInt(orcamentoId),
        marceneiroId: data.marceneiroId,
        valorProposto: data.valorProposto,
        detalhes: data.detalhes,
        status: "enviada",
        dataEnvio: new Date().toISOString(),
      }
    });
    
  } catch (error) {
    console.error("Erro ao processar proposta:", error);
    return NextResponse.json(
      { error: "Erro ao processar a proposta" },
      { status: 500 }
    );
  }
}
