import { NextRequest, NextResponse } from "next/server";

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const id = params.id;
    
    // Aqui seria feita a consulta ao banco de dados
    // Por enquanto, simulamos um orçamento
    
    // Simulação de orçamento
    const orcamento = {
      id: parseInt(id),
      cidade: "Campinas",
      tamanhoApartamento: "80",
      tipoOrcamento: "Apartamento completo",
      detalhes: "Preciso de móveis para todos os ambientes do meu apartamento novo.",
      valorEstimado: 176000,
      status: "pendente",
      dataCriacao: new Date().toISOString(),
      propostas: [
        {
          id: 1,
          marceneiroId: 101,
          marceneiroNome: "Marchetto Interni",
          valorProposto: 170000,
          detalhes: "Móveis planejados com acabamento premium para todos os ambientes.",
          status: "enviada",
          dataEnvio: new Date().toISOString(),
        },
        {
          id: 2,
          marceneiroId: 102,
          marceneiroNome: "Guaíra Ambientes Planejados",
          valorProposto: 165000,
          detalhes: "Projeto completo com materiais de primeira linha e garantia de 5 anos.",
          status: "enviada",
          dataEnvio: new Date().toISOString(),
        }
      ]
    };
    
    return NextResponse.json(orcamento);
    
  } catch (error) {
    console.error("Erro ao buscar orçamento:", error);
    return NextResponse.json(
      { error: "Erro ao buscar o orçamento solicitado" },
      { status: 500 }
    );
  }
}
