import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    // Aqui seria feita a consulta ao banco de dados
    // Por enquanto, simulamos uma lista de orçamentos
    
    // Parâmetros de filtro da URL
    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get("status");
    const cidade = searchParams.get("cidade");
    
    // Simulação de lista de orçamentos
    let orcamentos = [
      {
        id: 1001,
        cidade: "Campinas",
        tamanhoApartamento: "80",
        tipoOrcamento: "Apartamento completo",
        detalhes: "Preciso de móveis para todos os ambientes do meu apartamento novo.",
        valorEstimado: 176000,
        status: "pendente",
        dataCriacao: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 dias atrás
        clienteNome: "João Silva",
        clienteEmail: "joao.silva@exemplo.com"
      },
      {
        id: 1002,
        cidade: "São Paulo",
        tamanhoApartamento: "120",
        tipoOrcamento: "Alguns ambientes",
        detalhes: "Preciso de móveis para a cozinha e sala de estar.",
        valorEstimado: 180000,
        status: "em_analise",
        dataCriacao: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), // 5 dias atrás
        clienteNome: "Maria Oliveira",
        clienteEmail: "maria.oliveira@exemplo.com"
      },
      {
        id: 1003,
        cidade: "Campinas",
        tamanhoApartamento: "60",
        tipoOrcamento: "Móveis específicos",
        detalhes: "Preciso de um armário embutido para o quarto principal.",
        valorEstimado: 48000,
        status: "pendente",
        dataCriacao: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 dia atrás
        clienteNome: "Pedro Santos",
        clienteEmail: "pedro.santos@exemplo.com"
      },
      {
        id: 1004,
        cidade: "Jundiaí",
        tamanhoApartamento: "90",
        tipoOrcamento: "Apartamento completo",
        detalhes: "Apartamento novo, preciso mobiliar todos os cômodos.",
        valorEstimado: 198000,
        status: "aceito",
        dataCriacao: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(), // 10 dias atrás
        clienteNome: "Ana Souza",
        clienteEmail: "ana.souza@exemplo.com"
      }
    ];
    
    // Aplicar filtros se fornecidos
    if (status) {
      orcamentos = orcamentos.filter(o => o.status === status);
    }
    
    if (cidade) {
      orcamentos = orcamentos.filter(o => o.cidade.toLowerCase().includes(cidade.toLowerCase()));
    }
    
    return NextResponse.json({
      success: true,
      orcamentos: orcamentos
    });
    
  } catch (error) {
    console.error("Erro ao listar orçamentos:", error);
    return NextResponse.json(
      { error: "Erro ao listar os orçamentos" },
      { status: 500 }
    );
  }
}
