import React from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";

interface ChatMessage {
  type: "bot" | "user" | "option";
  content: string;
}

interface ChatbotProps {
  onSubmit?: (data: any) => void;
}

const Chatbot: React.FC<ChatbotProps> = ({ onSubmit }) => {
  const [messages, setMessages] = React.useState<ChatMessage[]>([
    {
      type: "bot",
      content: "Oi! Tudo bem? 😊",
    },
    {
      type: "bot",
      content: "Para calcularmos um orçamento \"sob medida\", precisamos que você preencha as informações dos móveis planejados que você deseja. ✍️",
    },
    {
      type: "bot",
      content: "Para qual cidade é seu orçamento?",
    },
  ]);
  
  const [input, setInput] = React.useState("");
  const [step, setStep] = React.useState(0);
  const [formData, setFormData] = React.useState({
    cidade: "",
    tamanhoApartamento: "",
    tipoOrcamento: "",
    detalhes: "",
  });
  
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  React.useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (!input.trim()) return;

    // Adiciona mensagem do usuário
    setMessages((prev) => [...prev, { type: "user", content: input }]);
    
    // Processa a resposta com base no passo atual
    processStep(input);
    
    // Limpa o input
    setInput("");
  };

  const handleOptionClick = (option: string) => {
    // Adiciona a opção selecionada como mensagem do usuário
    setMessages((prev) => [...prev, { type: "user", content: option }]);
    
    // Processa a resposta com base no passo atual
    processStep(option);
  };

  const processStep = (userInput: string) => {
    switch (step) {
      case 0: // Cidade
        setFormData((prev) => ({ ...prev, cidade: userInput }));
        setMessages((prev) => [
          ...prev,
          {
            type: "bot",
            content: `Quantos m² tem seu apartamento? Caso você não saiba exatamente, responda com o valor aproximado. 📏`,
          },
        ]);
        setStep(1);
        break;
      case 1: // Tamanho do apartamento
        setFormData((prev) => ({ ...prev, tamanhoApartamento: userInput }));
        setMessages((prev) => [
          ...prev,
          {
            type: "bot",
            content: "Perfeito! Antes da próxima pergunta, precisamos te explicar nossos tipos de orçamentos, são eles:",
          },
          {
            type: "bot",
            content: "Apartamento completo: inclui móveis em todos os ambientes do seu Apê.\n\nAlguns ambientes: móveis em apenas um ou mais ambientes do Apê.\n\nMóveis específicos: quando o orçamento é apenas para um ou mais móveis em determinados ambientes (ex: um aparador de 3 portas de abrir na sala de estar, na cor amadeirado).",
          },
          {
            type: "bot",
            content: "Selecione o tipo de orçamento que você precisa:",
          },
          {
            type: "option",
            content: "Apartamento completo",
          },
          {
            type: "option",
            content: "Alguns ambientes",
          },
          {
            type: "option",
            content: "Apenas móveis específicos",
          },
        ]);
        setStep(2);
        break;
      case 2: // Tipo de orçamento
        setFormData((prev) => ({ ...prev, tipoOrcamento: userInput }));
        setMessages((prev) => [
          ...prev,
          {
            type: "bot",
            content: "Ótimo! Agora, por favor, descreva com mais detalhes o que você precisa:",
          },
        ]);
        setStep(3);
        break;
      case 3: // Detalhes
        setFormData((prev) => ({ ...prev, detalhes: userInput }));
        setMessages((prev) => [
          ...prev,
          {
            type: "bot",
            content: "Obrigado pelas informações! Com base nos dados fornecidos, preparamos um orçamento estimado para você.",
          },
          {
            type: "bot",
            content: `Orçamento estimado para um apartamento de ${formData.tamanhoApartamento}m² em ${formData.cidade} (${formData.tipoOrcamento}): R$ ${calcularOrcamentoEstimado(formData.tamanhoApartamento, formData.tipoOrcamento)}`,
          },
          {
            type: "bot",
            content: "Deseja receber propostas personalizadas de marceneiros da sua região?",
          },
          {
            type: "option",
            content: "Sim, quero receber propostas",
          },
          {
            type: "option",
            content: "Não, apenas o orçamento estimado",
          },
        ]);
        setStep(4);
        break;
      case 4: // Decisão final
        if (userInput.includes("Sim")) {
          setMessages((prev) => [
            ...prev,
            {
              type: "bot",
              content: "Ótimo! Para receber propostas personalizadas, precisamos de algumas informações de contato.",
            },
            {
              type: "bot",
              content: "Por favor, informe seu nome completo, e-mail e telefone para que os marceneiros possam entrar em contato com você.",
            },
          ]);
          setStep(5);
        } else {
          setMessages((prev) => [
            ...prev,
            {
              type: "bot",
              content: "Entendido! Você pode salvar este orçamento estimado para referência futura. Se mudar de ideia, você pode retornar a qualquer momento para solicitar propostas de marceneiros.",
            },
            {
              type: "bot",
              content: "Obrigado por usar nossa plataforma! Esperamos ter ajudado.",
            },
          ]);
          // Finaliza o chatbot
          if (onSubmit) {
            onSubmit({ ...formData, receberPropostas: false });
          }
        }
        break;
      case 5: // Informações de contato
        setMessages((prev) => [
          ...prev,
          {
            type: "bot",
            content: "Perfeito! Suas informações foram registradas com sucesso.",
          },
          {
            type: "bot",
            content: "Seu pedido de orçamento foi enviado para marceneiros da região de " + formData.cidade + ". Em breve, você receberá propostas personalizadas no e-mail informado.",
          },
          {
            type: "bot",
            content: "Você também pode acompanhar as propostas e se comunicar com os marceneiros através da sua área de cliente na nossa plataforma.",
          },
          {
            type: "bot",
            content: "Obrigado por usar nossa plataforma! Estamos à disposição para qualquer dúvida.",
          },
        ]);
        // Finaliza o chatbot
        if (onSubmit) {
          onSubmit({ ...formData, receberPropostas: true, contato: userInput });
        }
        break;
      default:
        break;
    }
  };

  const calcularOrcamentoEstimado = (tamanho: string, tipo: string): string => {
    const tamanhoNum = parseInt(tamanho);
    let valorBase = 0;
    
    if (tipo.includes("completo")) {
      valorBase = tamanhoNum * 2200;
    } else if (tipo.includes("ambientes")) {
      valorBase = tamanhoNum * 1500;
    } else {
      valorBase = tamanhoNum * 800;
    }
    
    // Formata o valor para exibição
    return valorBase.toLocaleString('pt-BR');
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-xl text-orange-600">Orçamento Instantâneo</CardTitle>
        <CardDescription>
          Responda algumas perguntas para receber um orçamento personalizado
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 max-h-[400px] overflow-y-auto p-2">
          {messages.map((message, index) => {
            if (message.type === "bot") {
              return (
                <div key={index} className="flex items-start">
                  <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center mr-2 flex-shrink-0">
                    <span className="text-orange-600 text-sm">MB</span>
                  </div>
                  <div className="bg-gray-100 rounded-lg p-3 max-w-[80%]">
                    <p className="text-gray-800 whitespace-pre-line">{message.content}</p>
                  </div>
                </div>
              );
            } else if (message.type === "user") {
              return (
                <div key={index} className="flex items-start justify-end">
                  <div className="bg-orange-600 text-white rounded-lg p-3 max-w-[80%]">
                    <p>{message.content}</p>
                  </div>
                </div>
              );
            } else if (message.type === "option") {
              return (
                <div key={index} className="flex justify-center">
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => handleOptionClick(message.content)}
                  >
                    {message.content}
                  </Button>
                </div>
              );
            }
            return null;
          })}
          <div ref={messagesEndRef} />
        </div>
      </CardContent>
      <CardFooter className="flex flex-col space-y-2">
        {step < 4 && step !== 2 && (
          <div className="flex w-full space-x-2">
            <Input
              placeholder="Digite sua mensagem..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              className="flex-1"
            />
            <Button onClick={handleSendMessage}>Enviar</Button>
          </div>
        )}
        {step === 3 && (
          <Textarea
            placeholder="Descreva com detalhes o que você precisa..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full"
          />
        )}
        {step === 5 && (
          <div className="space-y-2 w-full">
            <Input
              placeholder="Nome completo"
              className="w-full"
              onChange={(e) => setInput(e.target.value)}
            />
            <Input
              placeholder="E-mail"
              type="email"
              className="w-full"
            />
            <Input
              placeholder="Telefone"
              type="tel"
              className="w-full"
            />
            <Button className="w-full" onClick={handleSendMessage}>
              Enviar informações
            </Button>
          </div>
        )}
      </CardFooter>
    </Card>
  );
};

export default Chatbot;
